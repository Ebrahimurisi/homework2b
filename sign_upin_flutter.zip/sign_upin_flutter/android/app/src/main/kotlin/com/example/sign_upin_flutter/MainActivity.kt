package com.example.sign_upin_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
